﻿namespace GestionCursosAPI.Models
{
    public class Curso
    {
        public int? Id { get; set; }
        public string Nombre { get; set; }
        public int Creditos { get; set; }
    }
}
