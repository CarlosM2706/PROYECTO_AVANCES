﻿namespace GestionCursosAPI.Models
{
    public class LoginRequestt
    {
        public string Username { get; set; }
        public string Password { get; set; }
    }
}
